from django.contrib import admin
from .models import ExpenseList

# Register your models here.

admin.site.register(ExpenseList)
